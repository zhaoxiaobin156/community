//
//  MBCViewController.h
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import <UIKit/UIKit.h>
@class QDCommunityModel;

@interface MBCViewController : UIViewController

@property(nonatomic,strong)QDCommunityModel *topmodel;

@end
