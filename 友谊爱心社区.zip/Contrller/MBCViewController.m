//
//  MBCViewController.m
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import "MBCViewController.h"

#import "QDCommunityModel.h"

#define DURL @"http://admin.xuexibo.cn/portapi/community/topiclist"
#import <AFNetworking.h>
#import <MJExtension.h>

#import "MBCModel.h"
#import "MBCModel2.h"
#import "MBCCell.h"


@interface MBCViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableview;








@property(nonatomic,strong)AFHTTPSessionManager *manager;
@property(nonatomic,strong)NSMutableArray *dataSource;
@property(nonatomic,strong)NSMutableDictionary *dic;

@end

@implementation MBCViewController
-(NSMutableArray *)dataSource{
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}
-(AFHTTPSessionManager *)manager{
    if (!_manager) {
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
        _manager = manager;
    }
    return  _manager;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initialTableview];
    
    [self getMessage];
}
-(void)initialTableview{
    self.tableview.delegate = self;
    self.tableview.dataSource = self;
    self.tableview.estimatedRowHeight = 200;
    self.tableview.rowHeight = UITableViewAutomaticDimension;
    self.tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    
}
-(void)getMessage{
    [self.manager GET:self.topmodel.cate_url parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSMutableArray *mut = [MBCModel mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
        
        NSLog(@"%@",responseObject[@"data"]);
        for (MBCModel *model in mut) {
            MBCModel2 *model2 =[[MBCModel2 alloc]init];
            model2.model = model;
            
            [self.dataSource addObject:model2];
        }
        [self.tableview reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.dataSource.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return  1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MBCCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MBCCell"];
    
    cell.model2 = self.dataSource[indexPath.row];
    return  cell;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
