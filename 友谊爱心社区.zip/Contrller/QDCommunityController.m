//
//  QDCommunityController.m
//  Learning
//
//  Created by lin on 2017/9/20.
//  Copyright © 2017年 lin. All rights reserved.
//

#import "QDCommunityController.h"

#define URL @"http://admin.xuexibo.cn/portapi/community/topiccate"


#import "MBCViewController.h"
#import "QDCommunityModel.h"
#import "MBMenu.h"

@interface QDCommunityController ()<UIScrollViewDelegate ,MBMenuDelegate>

@property(nonatomic,strong)MBMenu *menu;//标题栏
@property(nonatomic,strong)UIScrollView *contentScrollview;//存放scrollview 的 滚动视图

@property(nonatomic,strong)NSMutableArray *currentChannelsArray;//滚动菜单的名字

@property(nonatomic,strong)NSMutableArray *urlMut;//滚动菜单类别模型--主要是为了那到url ，所以这样命名

#pragma mark --一下参数决定是否要重新加载视图

@property(nonatomic,assign)BOOL isChild;//是否已经加载过子控制体
@property(nonatomic,assign)BOOL isContent;//是否已经加载过contentview

@property(nonatomic,assign)BOOL isContainer;//是否加载过container；



@end

@implementation QDCommunityController

#pragma mark ---发帖按钮


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [self setNavigation];
    
    [self MBCreatArray];
    
    // [self moniterNetStatus];
    
    //[self getCategeryListInfoFromNet];
    
    [self af];
    
}



-(void)setNavigation{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.title = @"社区";
}
-(void)MBCreatArray{
    
    _currentChannelsArray =[NSMutableArray array];
    _urlMut = [NSMutableArray array];
    
}
-(void)af{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //申明请求的数据是json类型
    manager.requestSerializer=[AFJSONRequestSerializer serializer];
    //如果报接受类型不一致请替换一致text/html或别的
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",
                                                         @"text/html",
                                                         @"image/jpeg",
                                                         @"image/png",
                                                         @"application/octet-stream",
                                                         @"text/json",
                                                         nil];
    
    [manager POST:URL parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSArray *keyValuesArr = responseObject[@"data"];
        
        NSArray *categeryList = [QDCommunityModel mj_objectArrayWithKeyValuesArray:keyValuesArr];
        for (QDCommunityModel *model in categeryList) {
            [_currentChannelsArray addObject:model.title];
            [_urlMut addObject:model];
        }
        
        
        [self setupTopMenu];
        [self setUpChildController];
        [self setContentScrollview];
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"%@",error);
        
    }];
    
    
    
}
-(void)setupTopMenu{
    MBMenu *menu = [[MBMenu alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 45)];
    menu.backgroundColor  =[UIColor redColor];
    
    menu.mut = self.currentChannelsArray;
    self.menu = menu;
    
    menu.delegate = self;
    [self.view addSubview: menu];
    
    
}
-(void)setContentScrollview{
    
    CGRect rect =  CGRectMake(0, 45, self.view.bounds.size.width, self.view.bounds.size.height - 45 -1);
    
    UIScrollView *contentSCR = [[UIScrollView alloc]initWithFrame:rect];
    
    
    self.contentScrollview  = contentSCR;
    contentSCR.contentSize = CGSizeMake(contentSCR.bounds.size.width * self.currentChannelsArray.count, 0);
    contentSCR.pagingEnabled = YES;
    contentSCR.delegate = self;
    
    
    
    
    [self.view insertSubview:contentSCR atIndex:0];
    [self scrollViewDidEndScrollingAnimation:contentSCR];
    _isContent = YES;
}
-(void)setUpChildController{
    for (int i = 0; i < self.currentChannelsArray.count; i++) {
//        
//        MCViewController *tableVC = [[MCViewController alloc]init];
//        tableVC.topmodel = _urlMut[i];
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"MBCViewController" bundle:nil];
        MBCViewController *vc = [sb instantiateViewControllerWithIdentifier:@"mySB"];
        vc.topmodel = _urlMut[i];
        
        
        
        
#pragma mark ---give tableVc some properties;
        [self addChildViewController:vc];
    }
    _isChild = YES;
    
}
-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    if (scrollView == self.contentScrollview) {
        NSInteger index = scrollView.contentOffset.x /self.contentScrollview.frame.size.width;
        
        MBCViewController *vc = self.childViewControllers[index];
        vc.view.frame = CGRectMake(scrollView.contentOffset.x, 0, self.contentScrollview.frame.size.width, self.contentScrollview.frame.size.height);
       
        [scrollView addSubview:vc.view];
        
        for (int i = 0; i < self.contentScrollview.subviews.count; i ++) {
            int currentIndex = vc.view.frame.origin.x / self.contentScrollview.frame.size.width;
            
            if ([self.contentScrollview.subviews[i] isKindOfClass:[UITableView class]]) {
                UITableView *theTableview = self.contentScrollview.subviews[i];
                NSInteger theIndex = theTableview.frame.origin.x / self.contentScrollview.frame.size.width;
                
                NSInteger gap = theIndex  - currentIndex;
                if (gap <= 2 && gap >= -2) {
                    continue;
                }else{
                    [theTableview removeFromSuperview];
                }
            }
            
        }
        
    }
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == self.contentScrollview) {
        [self scrollViewDidEndScrollingAnimation:scrollView];
        NSInteger index = scrollView.contentOffset.x / self.contentScrollview.frame.size.width;
        //[self.topContianerView selectChannelButtonWithIndex:index];
        self.menu.num = index;
        
    }
}
#pragma mark --MBDelegate
-(void)MBMenuSelectedIndex:(NSInteger)index{
    
    [self.contentScrollview setContentOffset:CGPointMake(self.contentScrollview.frame.size.width * index, 0) animated:YES];
}


@end
