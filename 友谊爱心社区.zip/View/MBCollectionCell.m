//
//  MBCollectionCell.m
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import "MBCollectionCell.h"
#import <UIImageView+WebCache.h>

@interface MBCollectionCell ()
@property (weak, nonatomic) IBOutlet UIImageView *imgview;

@end

@implementation MBCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setImgURL:(NSString *)imgURL{
    _imgURL = imgURL;
    [self.imgview sd_setImageWithURL:[NSURL URLWithString:imgURL] placeholderImage:nil];
    
}

@end
