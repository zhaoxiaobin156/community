//
//  MBCollectionCell.h
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MBCollectionCell : UICollectionViewCell

@property(nonatomic,copy)NSString *imgURL;

@end
