//
//  MBCCell.h
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MBCModel2;

@interface MBCCell : UITableViewCell

@property(nonatomic,strong)MBCModel2 *model2;


@end
