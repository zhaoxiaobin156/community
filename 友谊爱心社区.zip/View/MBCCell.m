
//
//  MBCCell.m
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import "MBCCell.h"
#import "MBCModel2.h"
#import "MBCModel.h"

#import "MBCollectionCell.h"

#import <UIImageView+WebCache.h>


@interface MBCCell ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;

@property (weak, nonatomic) IBOutlet UILabel *CTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *CTimeLabel;

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;


//collectionview 的高度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *collectionViewHeight;


@property (weak, nonatomic) IBOutlet UICollectionView *collecView;



//佛斌拖的按钮--拖到这里



@end

static NSString *identy = @"MBCollectionCell";

@implementation MBCCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
}
-(void)setModel2:(MBCModel2 *)model2{
    _model2 = model2;
    
    [self.headImageView sd_setImageWithURL:[NSURL URLWithString:model2.model.img] placeholderImage:nil];
    self.CTimeLabel.text = model2.model.create_time_date;
    self.CTitleLabel.text = model2.model.autor;
    
    
    self.collectionViewHeight.constant = model2.collectionViewHeight;
    
    [self FBset];
    
    self.contentLabel.attributedText = [self getAttributedString:model2];
    
    
    [self setupCollectionView];//设置collectionview；
    
}

-(NSMutableAttributedString *)getAttributedString:(MBCModel2 *)model{
    NSString *all =[NSString stringWithFormat:@"#%@#  %@",model.model.cate_title,model.model.content];
    
    NSMutableAttributedString *att =[[NSMutableAttributedString alloc]initWithString:all];
    //[att setAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:0 green:165/256.0 blue:1 alpha:1]} range:NSMakeRange(0, model.model.cate_title.length+ 2)];
    
    
    
    
    NSMutableParagraphStyle *para = [[NSMutableParagraphStyle alloc]init];
    para.lineSpacing = 10;
    
    NSDictionary *dic =@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSParagraphStyleAttributeName:para};
    
     [att setAttributes:dic range:NSMakeRange(0, all.length)];
    [att addAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:0 green:165/256.0 blue:1. alpha:1]} range:NSMakeRange(0, model.model.cate_title.length + 2)];
    
    return  att;
    
}
-(void)setupCollectionView{
    
    self.collecView.delegate = self;
    self.collecView.dataSource = self;
    [self.collecView registerNib:[UINib nibWithNibName:@"MBCollectionCell" bundle:nil] forCellWithReuseIdentifier:identy];
    [self.collecView reloadData];
    
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return  _model2.model.url.count;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return  1;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MBCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identy forIndexPath:indexPath];
    
    cell.imgURL = _model2.model.url[indexPath.row];
    
    return  cell;
    
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    CGFloat picWid = (width - 33) / 3;
    return  CGSizeMake(picWid, picWid);
    
    
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return  6;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return  2;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


#pragma mark -----佛斌写---点赞品论分享---按钮时间拖到这里

-(void)FBset{
    
    
}


@end
