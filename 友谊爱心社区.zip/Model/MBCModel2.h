//
//  MBCModel2.h
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MBCModel;

@interface MBCModel2 : NSObject

@property(nonatomic,strong)MBCModel *model;




//@property(nonatomic,assign,readonly)CGFloat contentHeight;
@property(nonatomic,assign,readonly)CGFloat collectionViewHeight;

//@property(nonatomic,assign,readonly)CGFloat allHeight;

@end
