//
//  MBCModel.h
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MBCModel : NSObject

/**
 标题
 */
@property(nonatomic,strong)NSString *autor;
/**
 类别标题
 */
@property(nonatomic,strong)NSString *cate_title;
/**
 照片
 */
@property(nonatomic,strong)NSString *img;

/**
 内容
 */
@property(nonatomic,strong)NSString *content;

/**
 存放图片url的数组
 */
@property(nonatomic,strong)NSArray *url;

/**
 发布时间
 */
@property(nonatomic,strong)NSString *create_time_date;
@property(nonatomic,copy)NSString *good;
@property(nonatomic,copy)NSString *account_num;

@end
