//
//  MBCModel.m
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import "MBCModel.h"

@implementation MBCModel

@end
