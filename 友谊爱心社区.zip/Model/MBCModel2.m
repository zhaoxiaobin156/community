

//
//  MBCModel2.m
//  MBC
//
//  Created by Ios on 17/9/29.
//  Copyright © 2017年 Ios. All rights reserved.
//

#import "MBCModel2.h"
#import "MBCModel.h"

@interface MBCModel2 ()

@property(nonatomic,assign)CGFloat collectionViewHeight;

@end

@implementation MBCModel2

-(void)setModel:(MBCModel *)model{
    _model = model;
    
    if (!_collectionViewHeight) {
    [self caculateCollectionHeight];
    }
    
    
}
-(void)caculateCollectionHeight{
    
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    CGFloat picWid = (width - 33) / 3;
    
    NSInteger count = _model.url.count;
    
    if (count) {
        NSInteger raw = (count - 1) / 3 + 1;
        _collectionViewHeight = raw * picWid + 30 + (raw - 1) * 5;
        
        
    }else{
        
        _collectionViewHeight = 15;
    }
   
    
    
}
-(CGFloat)collectionViewHeight{
    return  _collectionViewHeight;
}

@end
