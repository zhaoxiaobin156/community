//
//  QDCommunityModel.h
//  Learning
//
//  Created by lin on 2017/9/22.
//  Copyright © 2017年 lin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QDCommunityModel : NSObject

@property(nonatomic,copy)NSString *title;

@property(nonatomic,copy)NSString *cate_url;





@property(nonatomic,copy)NSString *remark;
@property(nonatomic,copy)NSString *create_time;
@property(nonatomic,copy)NSString *cate_description;

@property(nonatomic,copy)NSString *upload_url;

@end
